/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:37
*/

//企业生命周期分析开始
// 基于准备好的dom，初始化echarts实例
var myChart = echarts.init(document.getElementById('main'));
var app = {};
option = null;
// app.title = '堆叠条形图';
option = {
    title: {
        text: '企业全生命周期',
        top: '20',
        // textAlign: 'left',
        textStyle: {
            color: 'white',
            align: 'center'
        }
    },
    tooltip: {
        trigger: 'axis',

        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'|cross
        },
        //

    },
    legend: {
        data: ['庆阳', '全国', '世行'],
        bottom: '1',
        itemHeight: 15,
        itemWidth: 40,
        textStyle: {
            fontSize: 15,
            color: '#fff'
        }
    },
    grid: {
        left: '1%',
        right: '1%',
        bottom: '1%',
        containLabel: true
    },
    xAxis: {
        show: false,
        // type: 'value'
    },

    yAxis:
        {
            type: 'category',
            // splitLine:{show: false},//去除网格线
            // splitArea : {show : true},//保留网格区域
            axisLine: {
                lineStyle: {
                    type: 'solid',
                    color: '#151837',
                    width: '2'
                }
            },
            axisLabel: {
                textStyle: {
                    color: 'white',
                    align: 'right',
                    fontSize: 14
                    // padding: 2
                }
            },
            data: ['注销企业', '办理破产', '缴纳税费', '不动产登记', '获得网络', '获得用气', '获得电力', '办理建筑许可', '开办企业']

        },

    series: [
        {
            name: '庆阳',
            type: 'bar',
            stack: '总量',
            barWidth: '20',
            label: {
                normal: {
                    show: true,

                    position: 'inside',
                    // distance: 50,
                    // padding:50
                }
            },
            itemStyle: {
                color: '#5dc7de'
            },

            data: [32, 32, 31, 34, 30, 33, 32, 38, 32]
        },
        {
            name: '全国',
            type: 'bar',
            stack: '总量',
            barWidth: '20',
            label: {
                normal: {
                    show: true,
                    position: 'inside',
                    // distance: 50,
                    // padding:50
                }
            },
            itemStyle: {
                color: '#ebdb58'
            },
            data: [42, 43, 51, 63, 49, 63, 51, 66, 54]
        },
        {
            name: '世行',
            type: 'bar',
            stack: '总量',
            barWidth: '20',
            label: {
                normal: {
                    show: true,
                    position: 'inside',
                    // distance: 50,
                    // padding:50
                }
            },
            itemStyle: {
                color: '#f6716b'
            },
            data: [62, 58, 79, 63, 59, 63, 81, 90, 82]
        },
    ]
};

if (option && typeof option === "object") {
    myChart.setOption(option, true);
}

//企业生命周期分析结束

//吸引投资能力图开始
var myChartt = echarts.init(document.getElementById('main1'));
option = {
    title: {
        text: '吸引投资能力',
        color: 'white',
        top: 10,
        textStyle: {
            color: 'white',
            // margin-top:'10',
        },
        // left: 180
        x: 'center'

    },
    tooltip: {
        trigger: 'item',
        backgroundColor: 'rgba(0,0,250,0.2)'
    },

    legend: {
        type: 'scroll',
        bottom: 10,
        data: (function () {
            var list = [];
            for (var i = 1; i <= 5; i++) {
                list.push(i + 2018 + '');
            }
            return list;
        })()
    },

    radar: {
        indicator: [
            {text: '跨境贸易', max: 400},
            {text: '招标\n投标', max: 400},
            {text: '保护中小\n托资者', max: 400},
            {text: '执行合同', max: 400},
            {text: '获得\n信贷', max: 400}
        ],
        center: ['50%', '50%']  //组件的中心
    },
    series: (function () {
        var series = [];
        for (var i = 1; i <= 5; i++) {
            series.push({
                name: '浏览器（数据纯属虚构）',
                type: 'radar',
                symbol: 'none',
                lineStyle: {
                    width: 1
                },
                emphasis: {
                    areaStyle: {
                        color: 'rgba(0,250,0,0.3)'
                        // color:'red'
                    }
                },
                data: [
                    {
                        value: [
                            (40 - i) * 10,
                            (38 - i) * 4 + 60,
                            i * 5 + 10,
                            i * 9,
                            i * i / 2
                        ],
                        name: i + 2018 + ''
                    }
                ]
            });
        }
        return series;
    })()
};
if (option && typeof option === "object") {
    myChartt.setOption(option, true);
}

//吸引投资能力图结束
// 城市高质量发展水平图开始
var myChart1 = echarts.init(document.getElementById('main2'));
option = {
    title: {
        text: '城市高质量发展水平',
        // subtext: '纯属虚构',
        top: 10,
        textStyle: {
            color: 'white',
            // margin-top:'10',
        },
        x: 'center'
    },
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    color:['#ff9f7f', '#96beff','#37a1da','#33c4e9','#aefdca','#ffdb5c'],


    calculable: true,
    series: [

        {
            name: '发展水平',
            type: 'pie',
            radius: [10, 85],
            center: ['50%', '50%'],
            // width: '100%',
            roseType: 'area',
            data: [
                {value: 20, name: '知识权\n保护'},
                {value: 10, name: '企业\n信心'},
                {value: 5, name: '就业质量'},
                {value: 15, name: '基础设施'},
                {value: 25, name: '生活\n质量'},
                {value: 35, name: '信用环境'}

            ]
        }
    ]
};
if (option && typeof option === "object") {
    myChart1.setOption(option, true);
}
// 城市高质量发展水平图结束

// 中间的图开始
var myCharttt = echarts.init(document.getElementById('main5'));
var lineColor = '#e53935';
var crcolors = ['#f6909e', '#83dce7', '#fad797', '#59ccf7', '#c3b4df'];


var nodes = [
    {name: '城市高质量发展', symbolSize: 50, category: '城市高质量发展'},
    {name: '吸引投资能力', symbolSize: 50, category: '吸引投资能力'},
    {name: '企业生命周期', symbolSize: 50, category: '企业生命周期'},
    {name: '信用环境', symbolSize: 20, category: '信用环境'},
    {name: '知识产权保护', symbolSize: 20, category: '知识产权保护'},
    {name: '生活品质', symbolSize: 20, category: '生活品质'},
    {name: '基础设施', symbolSize: 20, category: '基础设施'},
    {name: '就业质量', symbolSize: 20, category: '就业质量'},
    {name: '企业信心', symbolSize: 20, category: '企业信心'},

    {name: '跨境贸易', symbolSize: 20, category: '跨境贸易'},
    {name: '获得信贷', symbolSize: 20, category: '获得信贷'},
    {name: '执行合同', symbolSize: 20, category: '执行合同'},
    {name: '保护中小投资者', symbolSize: 20, category: '保护中小投资者'},
    {name: '招标投标', symbolSize: 20, category: '招标投标'},
    {name: '政府采购', symbolSize: 20, category: '政府采购'},
    {name: '市场开放度', symbolSize: 20, category: '市场开放度'},


    {name: '注销企业', symbolSize: 20, category: '注销企业'},
    {name: '办理破产', symbolSize: 20, category: '办理破产'},
    {name: '缴纳税费', symbolSize: 20, category: '缴纳税费'},
    {name: '不动产登记', symbolSize: 20, category: '不动产登记'},
    {name: '获得网络', symbolSize: 20, category: '获得网络'},
    {name: '获得用气', symbolSize: 20, category: '获得用气'},
    {name: '获得用水', symbolSize: 20, category: '获得用水'},
    {name: '获得用电', symbolSize: 20, category: '获得用电'},
    {name: '办理建筑许可', symbolSize: 20, category: '办理建筑许可'},
    {name: '开办企业', symbolSize: 20, category: '开办企业'}
];

var legends = [
    {name: '城市高质量发展'},
    {name: '吸引投资能力'},
    {name: '企业生命周期'},
    {name: '信用环境'},
    {name: '知识产权保护'},
    {name: '生活品质'},
    {name: '基础设施'},
    {name: '就业质量'},
    {name: '企业信心'},

    {name: '跨境贸易'},
    {name: '获得信贷'},
    {name: '执行合同'},
    {name: '保护中小投资者'},
    {name: '招标投标'},
    {name: '政府采购'},
    {name: '市场开放度'},

    {name: '注销企业'},
    {name: '办理破产'},
    {name: '缴纳税费'},
    {name: '不动产登记'},
    {name: '获得网络'},
    {name: '获得用气'},
    {name: '获得用水'},
    {name: '获得用电'},
    {name: '办理建筑许可'},
    {name: '开办企业'}
];

var links = [

    {source: '城市高质量发展', target: '信用环境'},
    {source: '城市高质量发展', target: '知识产权保护'},
    {source: '城市高质量发展', target: '生活品质'},
    {source: '城市高质量发展', target: '基础设施'},
    {source: '城市高质量发展', target: '知识产权保护'},
    {source: '城市高质量发展', target: '就业质量'},
    {source: '城市高质量发展', target: '企业信心'},
    {source: '城市高质量发展', target: '基础设施'},
    {source: '城市高质量发展', target: '知识产权保护'},
    {source: '城市高质量发展', target: '就业质量'},
    {source: '城市高质量发展', target: '生活品质'},
    {source: '城市高质量发展', target: '基础设施'},
    {source: '城市高质量发展', target: '知识产权保护'},
    {source: '城市高质量发展', target: '就业质量'},
    {source: '城市高质量发展', target: '生活品质'},
    {source: '城市高质量发展', target: '基础设施'},
    {source: '城市高质量发展', target: '知识产权保护'},
    {source: '城市高质量发展', target: '就业质量'},


    {source: '吸引投资能力', target: '跨境贸易'},
    {source: '吸引投资能力', target: '获得信贷'},
    {source: '吸引投资能力', target: '执行合同'},
    {source: '吸引投资能力', target: '保护中小投资者'},
    {source: '吸引投资能力', target: '招标投标'},
    {source: '吸引投资能力', target: '政府采购'},
    {source: '吸引投资能力', target: '市场开放度'},


    {source: '企业生命周期', target: '注销企业'},
    {source: '企业生命周期', target: '办理破产'},
    {source: '企业生命周期', target: '缴纳税费'},
    {source: '企业生命周期', target: '不动产登记'},
    {source: '企业生命周期', target: '获得网络'},
    {source: '企业生命周期', target: '获得用气'},
    {source: '企业生命周期', target: '获得用水'},
    {source: '企业生命周期', target: '获得用电'},
    {source: '企业生命周期', target: '办理建筑许可'},
    {source: '企业生命周期', target: '开办企业'}


];


var option = {

    legend: [{
        //selectedMode: 'single',
        data: legends,
        show: false
    }],

    animationDurationUpdate: 2,
    animationEasingUpdate: 'quinticInOut',

    series: [{
        type: 'graph',
        //tooltip: {},
        top: '20%',
        //left:'10%',71C8B1
        width: '50%',
        height: '70%',
        ribbonType: true,
        layout: 'circular',
        symbol: "pin", //图形 'circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow'
        symbolSize: [10, 10],
        edgeSymbol: ['roundRect', 'arrow'],
        edgeSymbolSize: [10, 10],
        circular: {
            rotateLabel: true
        },


        //layout: 'force',

        force: {
            initLayout: 'circular',
            repulsion: 50,
            gravity: 0.5,
            edgeLength: 500,
            layoutAnimation: true,
        },

        roam: false,
        focusNodeAdjacency: true,
        hoverAnimation: true,
        label: {
            normal: {
                position: 'center',
                fontWeight: 'bold',
                fontSize: 14,
                formatter: '{b}',
                normal: {
                    textStyle: {

                        fontFamily: '宋体'
                    }
                }
            }
        },
        draggable: true,
        itemStyle: {
            normal: {
                label: {
                    rotate: true,
                    show: true,


                },
                color: function (params) {
                    // build a color map as your need.
                    var colorList = [
                        '#87CEEB', '#CDCD00', '#EE7600', '#87CEEB', '#87CEEB',
                        '#87CEEB', '#87CEEB', '#87CEEB', '#87CEEB', '#CDCD00', '#CDCD00', '#CDCD00', '#CDCD00', '#CDCD00', '#CDCD00', '#CDCD00',
                        '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600', '#EE7600'
                    ];
                    return colorList[params.dataIndex]
                }

                // color:["yellow","red","black"],
                // color:'yellow'
                // color:["green","blue","white","blue","white","red","white","blue","red","blue","white","yellow"]
                // color: ["#ffff00", "#393f51", "#393f51", "#393f51", "#393f51", "#393f51", "#393f51", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7", "#85d6f7"] /* 内的颜色#393f51，外的颜色#85d6f7 */
            },
            emphasis: {
                label: {
                    show: true
                    // textStyle: null      // 默认使用全局文本样式，详见TEXTSTYLE
                }
            }
        },
        lineStyle: {
            normal: {
                color: lineColor, // lineColor
                width: 2,
                type: 'solid',
                opacity: 0.2,
                curveness: 0.3,
            },
        },
        categories: legends,

        data: nodes,
        // links: [],
        links: links
    }]
};
if (option && typeof option === "object") {
    myCharttt.setOption(option, true);
}
// 中间的图结束

window.onresize = function(){
    myChart.resize();
    myChartt.resize();
    myChart1.resize()
};

