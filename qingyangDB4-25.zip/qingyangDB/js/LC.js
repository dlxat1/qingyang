/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:49
*/

// 开办企业开始
var myChart = echarts.init(document.getElementById('main'));

var builderJson = {
    // "all": 10887,
    "charts": {
        "北京": 56,
        "天津": 67,
        "上海": 45,
        "深圳": 67,
        "杭州": 89,
        "郑州": 99,
        "北京": 87,
        "银川": 54,
        "西安": 67,
        "深圳": 79,
        "重庆": 67,
        "成都": 77,
        "乌海": 87,
        "三亚": 83,
        "二亚": 84,
        "一亚": 45,
        "金川": 56,
        "东莞": 67,
        "南京": 45,
        "苏州": 67,
        "荆州": 78
    }
};


var canvas = document.createElement('canvas');
var ctx = canvas.getContext('2d');
canvas.width = canvas.height = 100;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.globalAlpha = 0.08;
ctx.font = '20px Microsoft Yahei';
option = {
    backgroundColor: {
        type: 'pattern',
        image: canvas,
        repeat: 'repeat'
    },
    tooltip: {},
    title: [{
        text: '开办企业',
        // subtext: '总计 ' + builderJson.all,
        top: '2%',
        textStyle: {
            color: '#144e87',
            align: 'center'
        },
        x: '15%',
        textAlign: 'center'
    },],
    grid: {
        top: 50,
        width: '90%',
        bottom: '5%',
        left: 10,
        containLabel: true
    },
    xAxis: {
        show: false,
        type: 'value',
        max: builderJson.all,
        splitLine: {
            show: false
        }
    },
    yAxis: [{
        // show:false,
        type: 'category',
        data: Object.keys(builderJson.charts),
        axisLabel: {
            interval: 0,
            textStyle: {
                color: 'white',
                align: 'right',
                // right:'10%',
                fontSize: 12

            }
        },

        axisLine: {
            show: false
            //
        },
        axisTick: {
            show: false     //隐藏刻度

        }
    }],
    series: [{

        type: 'bar',
        barWidth: 20,
        stack: 'chart',
        z: 3,

        itemStyle: {

            normal: {
                color: 'red',
                label: {
                    show: true, //开启显示
                    position: 'right', //在上方显示
                    textStyle: { //数值样式
                        color: '#114e87',
                        fontSize: 16
                    }
                },

                barBorderRadius: [5, 5, 5, 5],
                color: new echarts.graphic.LinearGradient(
                    0, 0, 1, 0,
                    [
                        {offset: 0, color: '#181c41'},
                        {offset: 1, color: '#7fa6ce'}

                    ]
                )
            },

        },
        data: Object.keys(builderJson.charts).map(function (key) {
            return builderJson.charts[key];
        })
    }]
};
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
// 开办企业结束

//全生命周期开始
var myChartt = echarts.init(document.getElementById('main1'));
var data = [{
    name: '中部',
    itemStyle: {
        color: '#4caeea'
    },
    children: [{
        name: '一档',
        itemStyle: {
            color: '#164579'
        },

        children: [{
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }

        ]
    },
        {
            name: '二档',
            itemStyle: {
                color: '#164579'
            },

            children: [{
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#fba45d'
                }
            },

            ]
        }
    ]
}, {
    name: '东部',
    itemStyle: {
        color: '#5594f2'
    },
    children: [{
        name: '一档',
        itemStyle: {
            color: '#164579'
        },
        children: [{
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }]
    }, {
        name: '二挡',
        itemStyle: {
            color: '#164579'
        },
        children: [{
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#fba45d'
            }
        }]
    }, {
        name: '三挡',
        itemStyle: {
            color: '#164579'
        },
        children: [{
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#e6e059'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#e6e059'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#e6e059'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#e6e059',
                barWidth: 10
            }
        }]
    }]
}, {
    name: '西部',
    itemStyle: {
        color: '#5dc7de'
    },
    children: [{
        name: '一档',
        itemStyle: {
            color: '#164579'
        },
        children: [{
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }, {
            name: '武汉\n\n55.44',
            value: 1,
            itemStyle: {
                color: '#F6716A'
            }
        }]
    },
        {
            name: '二挡',
            itemStyle: {
                color: '#164579'
            },
            children: [{
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#fba45d'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#fba45d'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#fba45d'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#fba45d'
                }
            }]
        },
        {
            name: '三挡',
            itemStyle: {
                color: '#164579'
            },
            children: [{
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#e6e059'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#e6e059'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#e6e059'
                }
            }, {
                name: '武汉\n\n55.44',
                value: 1,
                itemStyle: {
                    color: '#e6e059',

                }
            }]
        }
    ]
}];

option = {
    title: {
        text: '企业全生命周期',

        textStyle: {
            fontSize: 18,
            align: 'center',
            color: 'white'
        },
        subtextStyle: {
            align: 'center'
        },

    },

    series: {
        type: 'sunburst',
        highlightPolicy: 'ancestor',
        data: data,
        radius: [0, '95%'],
        sort: null,
        levels: [{}, {
            r0: '15%',
            r: '45%',

            itemStyle: {
                borderWidth: 2,
                // color:'red'
            },
            label: {
                rotate: 'tangential'
            }
        }, {
            r0: '45%',
            r: '70%',
            label: {
                align: 'right'
            }
        }, {
            r0: '70%',
            r: '80%',
            label: {
                position: 'outside',
                padding: 3,
                silent: false,
                color: 'white'
            },
            itemStyle: {
                borderWidth: 3,

            }
        }]
    }
};
if (option && typeof option === "object") {
    myChartt.setOption(option, true);
}
//全生命周期结束
// 办理施工许可开始
var myChartr = echarts.init(document.getElementById('main3'));
option = {
    title: {
        text: '办理施工许可',
        textStyle: {
            color: '#114E87',
            fontSize: '24'

        }
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data: ['最高气温']
    },
    grid: {
        left: '1%',
        right: '5%',
        bottom: '1%',
        containLabel: true
    },

    xAxis: {
        type: 'category',
        axisLine: {
            lineStyle: {
                color: '#114E87'
            }
        },
        boundaryGap: false,
        data: ['北京', '上海', '深圳', '杭州', '南京', '苏州', '广州', '贵州', '银川', '西安', '重庆', '成都', '徐州', '庆阳', '兰州', '吴中', '乌海', '海口', '咸阳', '武汉', '中卫', '云南']
    },
    yAxis: {
        show: false,

    },
    series: [
        {
            name: '指数',
            type: 'line',
            data: [40, 45, 45.9, 52.1, 55, 57, 63, 58, 68, 64, 57, 68, 70, 63, 56, 59, 60, 64, 49, 58, 61, 68],
            showSymbol: true,
            // symbol: 'circle',     //设定为实心点
            symbol: 'image://img/ciricle.png',
            symbolSize: 40,   //设定实心点的大小
            hoverAnimation: true,
            animation: true,

            // 显示数值
            itemStyle: {
                normal: {
                    label: {
                        show: true,
                        formatter: "{c}",
                        position: 'inside',
                        textStyle: {
                            color: 'white',
                            fontSize: '18'
                        }
                    },
                    textColor: '#000',
                    lineStyle: {
                        color: '#114E87'
                    }
                },

            },

            markLine: {
                data: [
                    {type: 'average', name: '平均值'}
                ],
                lineStyle: {
                    color: '#114E87'
                }
            }
        },

    ]
};
if (option && typeof option === "object") {
    myChartr.setOption(option, true);
}
window.onresize = function(){
    myChart.resize();
    myChartt.resize();
    myChartr.resize()
};
