/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:46
*/

// 吸引投资能力开始
var myChart = echarts.init(document.getElementById('main4'));

option = {
    title: [{
        text: '吸引投资能力',
        top: '2%',
        textStyle: {
            color: '#144e87',
            align: 'center'
        },
        x: '15%',
        textAlign: 'center'
    },],

    angleAxis: {
        type: 'category',
        data: ['北京', '上海', '深圳', '杭州', '南京', '苏州', '广州', '贵州', '银川', '西安', '重庆', '成都', '徐州', '庆阳', '兰州', '吴中', '乌海', '海口', '咸阳', '武汉', '中卫', '云南'],
        z: 10,
        axisLabel: {
            color: 'white' //圈外文字颜色
        }
    },
    tooltip: {
        trigger: 'axis',
        confine: true
    },
    radiusAxis: {
        axisLine: {
            show: true,
            lineStyle: {
                color: "#00c7ff",
                width: 1,
                type: "solid"
            },
        },
        splitLine: {
            lineStyle: {
                color: "#00c7ff",
                width: 1,
                type: "solid"
            }
        }
    },
    polar: {},
    series: [{
        name: '指标',
        type: 'bar',
        data: [73, 55, 61, 32, 43, 54, 25, 32, 53, 44, 33, 52, 63, 44, 65, 71, 42, 53, 64, 33, 56, 66],
        coordinateSystem: 'polar',

        // stack: 'a'
        itemStyle: {
            // color:'#c96409'   //条子颜色
            normal: {
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: '#06B5D7'},                   //柱图渐变色
                        {offset: 0.5, color: '#44C0C1'},                 //柱图渐变色
                        {offset: 1, color: '#71C8B1'},                   //柱图渐变色
                    ]
                )
            },
            emphasis: {
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: '#71C8B1'},                  //柱图高亮渐变色
                        {offset: 0.7, color: '#44C0C1'},                //柱图高亮渐变色
                        {offset: 1, color: '#06B5D7'}                   //柱图高亮渐变色
                    ]
                )
            }


        }
    }],


};
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
// 吸引投资能力结束


// 获得信贷开始
var myChartt = echarts.init(document.getElementById('fmain'));
option = {
    title: {
        text: '获得信贷',
        subtext: '全国平均水平   ------',
        top: '2%',
        textStyle: {
            color: '#114E87',
            fontSize: '18',


        },
        subtextStyle: {
            color: '#4aadc3',
            fontSize: '14',
            align: 'right'
        }
    },
// 					legend: {
// 						show: true,
// 						data: ['指标',],
// 						right:'1%',
// 						textStyle:{
// 							color:'white'
// 						}
//
// 					},
    tooltip: {
        trigger: 'item',
        confine: true

    },

// 				    legend: {
// 				        data:['最高气温']
// 				    },
    grid: {
        // width:93%,
        height: '200',
        left: '1%',
        right: '5%',
        bottom: '1%',
        containLabel: true
    },

    xAxis: {
        type: 'category',
        offset: -20,     //X轴偏移值
        axisLine: {
            lineStyle: {
                color: '#114E87'
            }
        },
        boundaryGap: false,
        data: ['北京', '上海', '深圳', '杭州', '南京', '苏州', '广州', '贵州', '银川', '西安', '重庆', '成都', '徐州', '庆阳', '兰州', '吴中', '乌海', '海口', '咸阳', '武汉', '中卫', '云南']
    },
    yAxis: {
        show: false,

    },
    series: [
        {
            name: '指标',
            type: 'line',
            data: [40, 45, 45.9, 52.1, 55, 57, 63, 58, 68, 64, 57, 68, 70, 63, 56, 59, 60, 64, 49, 58, 61, 68],
            showSymbol: true,
            // symbol: 'circle',     //设定为实心点
            symbol: 'image://img/huang.png',
            symbolSize: 16,   //设定实心点的大小
            hoverAnimation: true,
            animation: true,

            // 显示数值
            itemStyle: {
                normal: {
                    label: {
                        show: true,
                        // formatter: "{c}",
                        position: 'top',
                        textStyle: {
                            color: 'white',
                            fontSize: '12'
                        }
                    },
                    textColor: '#000',
                    lineStyle: {

                        color: '#151837'
                    }
                },

            },

            markLine: {
                // name:'指标',
                data: [
                    {type: 'average', name: '平均值'}
                ],
                lineStyle: {
                    color: '#114E87'
                }
            }
        },

    ]
};
if (option && typeof option === "object") {
    myChartt.setOption(option, true);
}
// 获得信贷结束

// 执行合同开始
var myChartr = echarts.init(document.getElementById('fmain1'));
// 显示标题，图例和空的坐标轴
myChartr.setOption({
    title: {
        text: '执行合同',
        subtext: '全国平均水平   ------',
        top: '2%',
        textStyle: {
            color: '#144e87',
            align: 'center'
        },
        subtextStyle: {
            color: '#4aadc3',
            fontSize: '14',
            align: 'right'
        }
    },
    grid: {
        show: false,
        height: '200',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true,
        width: '98%'     //表宽度
    },
    tooltip: {
        trigger: 'item',
        confine: true

    },

    xAxis: {
        data: [],
        // show:false,
        "axisTick": {       //X轴刻度线
            "show": false
        },
        axisLine: {
            show: false
        },
        splitLine: {
            show: false
        },
        axisLabel: {
            interval: '0',

            textStyle: {
                color: '#144e87',
                align: 'center',
                fontSize: 10
                // padding: 2
            }
        },

    },

    yAxis: {
        show: false,
    },
    series: [{
        name: '指标',
        type: 'bar',
        data: [],
        barWidth: 20,
        // interval: 100,
        // itemGap:10,
        // nameGap:65,

        itemStyle: {


            normal: {
                // color:'red'	,
                label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    textStyle: { //数值样式
                        color: 'white',
                        fontSize: 12
                    }
                },


                barBorderRadius: [7, 7, 0, 0],
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: '#06B5D7'},                   //柱图渐变色
                        {offset: 0.5, color: '#44C0C1'},                 //柱图渐变色
                        {offset: 1, color: '#71C8B1'},                   //柱图渐变色
                    ]
                )
// 				            color: new echarts.graphic.LinearGradient(
// 				                0, 0, 1, 0,
// 				                [
// 				                    {offset: 0, color: '#7fa6ce'},
// 				                    {offset: 1, color: '#181c41'}
//
// 				                ]
// 				            )
            },

        },
        emphasis: {
            color: new echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                    {offset: 0, color: '#71C8B1'},                  //柱图高亮渐变色
                    {offset: 0.7, color: '#44C0C1'},                //柱图高亮渐变色
                    {offset: 1, color: '#06B5D7'}                   //柱图高亮渐变色
                ]
            )
        },
        markLine: {
            // name:'指标',
            data: [
                {type: 'average', name: '平均值'}
            ],
            lineStyle: {
                color: '#114E87'
            }
        }

    }]
});

// 异步加载数据
$.get('data.json').done(function (data) {
    // 填入数据
    myChartr.setOption({
        xAxis: {
            data: data.categories
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '指标',
            data: data.data
        }]
    });
});
// 执行合同结束
window.onresize = function(){
    myChart.resize();
    myChartt.resize();
    myChartr.resize()
};