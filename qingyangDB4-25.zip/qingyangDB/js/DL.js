/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:45
*/
// 获得信贷开始
var myChart = echarts.init(document.getElementById('mainld'));
option = {
    title: {
        text: '获得信贷',
        subtext: '全国平均水平   ------',
        top: '2%',
        textStyle: {
            color: '#114E87',
            fontSize: '18',


        },
        subtextStyle: {
            color: '#4aadc3',
            fontSize: '14',
            align: 'right'
        }
    },
    tooltip: {
        trigger: 'item',
        confine: true

    },

    grid: {
        // width:93%,
        height: '200',
        left: '1%',
        right: '5%',
        bottom: '1%',
        containLabel: true
    },

    xAxis: {
        type: 'category',
        offset: -20,     //X轴偏移值
        axisLine: {
            lineStyle: {
                color: '#114E87'
            }
        },
        boundaryGap: false,
        data: ['北京', '上海', '深圳', '杭州', '南京', '苏州', '广州', '贵州', '银川', '西安', '重庆', '成都', '徐州', '庆阳', '兰州', '吴中', '乌海', '海口', '咸阳', '武汉', '中卫', '云南'],
    },
    yAxis: {
        show: false,

    },
    series: [
        {
            name: '指标',
            type: 'line',
            data: [40, 45, 45.9, 52.1, 55, 57, 63, 58, 68, 64, 57, 68, 70, 63, 56, 59, 60, 64, 49, 58, 61, 68],
            showSymbol: true,
            // symbol: 'circle',     //设定为实心点
            symbol: 'image://img/huang.png',
            symbolSize: 16,   //设定实心点的大小
            hoverAnimation: true,
            animation: true,

            // 显示数值
            itemStyle: {
                normal: {
                    label: {
                        show: true,
                        // formatter: "{c}",
                        position: 'top',
                        textStyle: {
                            color: 'white',
                            fontSize: '12'
                        }
                    },
                    textColor: '#000',
                    lineStyle: {
                        // show:false,
                        // color: '#114E87',
                        color: '#151837'
                    }
                },

            },

            markLine: {
                // name:'指标',
                data: [
                    {type: 'average', name: '平均值'}
                ],
                lineStyle: {
                    color: '#114E87'
                }
            }
        },

    ]
};
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
;
// 获得信贷结束
// 城市高质量发展水平开始
// 基于准备好的dom，初始化echarts实例
//var myChart = echarts.init(document.getElementById('main'));

var chart1 = echarts.init(document.getElementById('mainr'));

var data = [

    {name: '唐山', value: 119},
    {name: '平顶山', value: 119},
    {name: '邢台', value: 119},
    {name: '德州', value: 120},
    {name: '济宁', value: 120},
    {name: '荆州', value: 127},
    {name: '宜昌', value: 130},
    {name: '义乌', value: 132},
    {name: '丽水', value: 133},
    {name: '洛阳', value: 134},
    {name: '秦皇岛', value: 136},
    {name: '株洲', value: 143},
    {name: '石家庄', value: 147},
    {name: '莱芜', value: 148},
    {name: '常德', value: 152},
    {name: '保定', value: 153},
    {name: '湘潭', value: 154},
    {name: '金华', value: 157},
    {name: '岳阳', value: 169},
    {name: '长沙', value: 175},
    {name: '衢州', value: 177},
    {name: '廊坊', value: 193},
    {name: '菏泽', value: 194},
    {name: '合肥', value: 229},
    {name: '武汉', value: 273},
    {name: '大庆', value: 279}
];
var geoCoordMap = {

    '唐山': [118.02, 39.63],
    '平顶山': [113.29, 33.75],
    '邢台': [114.48, 37.05],
    '德州': [116.29, 37.45],
    '济宁': [116.59, 35.38],
    '荆州': [112.239741, 30.335165],
    '宜昌': [111.3, 30.7],
    '义乌': [120.06, 29.32],
    '丽水': [119.92, 28.45],
    '洛阳': [112.44, 34.7],
    '秦皇岛': [119.57, 39.95],
    '株洲': [113.16, 27.83],
    '石家庄': [114.48, 38.03],
    '莱芜': [117.67, 36.19],
    '常德': [111.69, 29.05],
    '保定': [115.48, 38.85],
    '湘潭': [112.91, 27.87],
    '金华': [119.64, 29.12],
    '岳阳': [113.09, 29.37],
    '长沙': [113, 28.21],
    '衢州': [118.88, 28.97],
    '廊坊': [116.7, 39.53],
    '菏泽': [115.480656, 35.23375],
    '合肥': [117.27, 31.86],
    '武汉': [114.31, 30.52],
    '大庆': [125.03, 46.58]
};

var convertData = function (data) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = geoCoordMap[data[i].name];
        if (geoCoord) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].value)
            });
        }
    }
    return res;
};

option = {
    backgroundColor: '#151837',
    title: {
        text: '城市高质量发展水平',
        //         subtext: 'data from PM25.in',
        //         sublink: 'http://www.pm25.in',
        left: 'left',
        top: '20',
        textStyle: {
            color: '#fff'
        }
    },
    tooltip: {
        trigger: 'item'
    },
    legend: {
        orient: 'vertical',
        // y: 'bottom',
        // x: 'right',
        top: 30,
        right:'2%',
        data: ['高水平', '可提升'],
        textStyle: {
            color: 'white'
        }
    },
    geo: {
        map: 'china',
        zoom:1.2,
        label: {
            emphasis: {
                show: false
            }
        },
        roam: false,   //地图放大缩小
        itemStyle: {
            normal: {
                areaColor: '#44AED0',
                borderColor: '#111'
            },
            emphasis: {
                areaColor: '#2a333d'
            }
        }
    },
    series: [
        {
            name: '高水平',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: convertData(data),
            symbolSize: function (val) {
                return val[2] / 10;
            },
            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: false
                },
                emphasis: {
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: 'yellow'
                }
            }
        },
        {
            name: '可提升',
            type: 'effectScatter',
            coordinateSystem: 'geo',
            data: convertData(data.sort(function (a, b) {
                return b.value - a.value;
            }).slice(0, 6)),
            symbolSize: function (val) {
                return val[2] / 10;
            },
            showEffectOn: 'render',
            rippleEffect: {
                brushType: 'stroke'
            },
            hoverAnimation: true,
            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: 'blue',
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            zlevel: 1
        },

    ]
};

chart1.setOption(option);
// 城市高质量发展水平结束


// 知识产权保护开始
var myChartt = echarts.init(document.getElementById('mainlu'));
// 显示标题，图例和空的坐标轴
myChartt.setOption({
    title: {
        text: '知识产权保护',
        subtext: '全国平均水平   ------',
        top: '2%',
        textStyle: {
            color: '#144e87',
            align: 'center'
        },
        subtextStyle: {
            color: '#4aadc3',
            fontSize: '14',
            align: 'right'
        }
    },
    grid: {
        show: false,
        height: '200',
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true,
        width: '98%'     //表宽度
    },
    tooltip: {
        trigger: 'item',
        confine: true

    },

    xAxis: {
        data: [],
        // show:false,
        "axisTick": {       //X轴刻度线
            "show": false
        },
        axisLine: {
            show: false
        },
        splitLine: {
            show: false
        },
        axisLabel: {
            interval: '0',

            textStyle: {
                color: '#144e87',
                align: 'center',
                fontSize: 14
                // padding: 2
            }
        },

    },

    yAxis: {
        show: false,
    },
    series: [{
        name: '指标',
        type: 'bar',
        data: [],
        barWidth: 20,
        // interval: 100,
        // itemGap:10,
        // nameGap:65,

        itemStyle: {

            normal: {
                color: 'red',
                label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    textStyle: { //数值样式
                        color: 'white',
                        fontSize: 12
                    }
                },
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: '#06B5D7'},                   //柱图渐变色
                        {offset: 0.5, color: '#44C0C1'},                 //柱图渐变色
                        {offset: 1, color: '#71C8B1'},                   //柱图渐变色
                    ]
                ),
                barBorderRadius: [8, 8, 0, 0],

            },

        },
        emphasis: {
            color: new echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                    {offset: 0, color: '#71C8B1'},                  //柱图高亮渐变色
                    {offset: 0.7, color: '#44C0C1'},                //柱图高亮渐变色
                    {offset: 1, color: '#06B5D7'}                   //柱图高亮渐变色
                ]
            )
        },
        markLine: {
            // name:'指标',
            data: [
                {type: 'average', name: '平均值'}
            ],
            lineStyle: {
                color: '#114E87'
            }
        }

    }]
});

// 异步加载数据
$.get('data.json').done(function (data) {
    // 填入数据
    myChartt.setOption({
        xAxis: {
            data: data.categories
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '指标',
            data: data.data
        }]
    });
});
// 知识产权保护结束
window.onresize = function(){
    myChart.resize();
    myChartt.resize();
    chart1.resize();

};