/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:42
*/

// 企业生命周期开始
var myChart = echarts.init(document.getElementById('main1'));

var builderJson = {
    // "all": 10887,
    "charts": {
        "杭州": 3237,
        "北京": 2164,
        "沈阳": 7561,
        "天津": 7778,
        "银川": 7355,

    }
};


var canvas = document.createElement('canvas');
var ctx = canvas.getContext('2d');
canvas.width = canvas.height = 100;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.globalAlpha = 0.08;
ctx.font = '20px Microsoft Yahei';
// ctx.translate(50, 50);
// ctx.rotate(-Math.PI / 4);


option = {
    backgroundColor: {
        type: 'pattern',
        image: canvas,
        repeat: 'repeat'
    },
    tooltip: {},
    title: [{
        text: '企业全生命周期-TOP5',
        // subtext: '总计 ' + builderJson.all,
        x: '25%',
        top: '10',
        textAlign: 'left',
        textStyle: {
            color: 'white',
            // margin-top:'10',
        }

    },],
    grid: {
        top: 50,
        width: '88%',
        bottom: '5%',
        left: 10,
        containLabel: true
    },
    xAxis: {

        type: 'value',
        show: false,
        max: builderJson.all,
        splitLine: {
            show: false
        },
        axisLabel: {
            color: 'red'
        }

    },
    yAxis: [{
        // show:false,
        type: 'category',
        data: Object.keys(builderJson.charts),
        axisLabel: {
            interval: 0,
            textStyle: {
                color: 'white',
                align: 'right'

            }
        },
        axisLine: {
            show: false
            //
        },
        axisTick: {
            show: false     //隐藏刻度

        },

    }],
    series: [{
        type: 'bar',
        stack: 'chart',
        barWidth: '16',
        z: 3,
        itemStyle: {
            barBorderRadius: 5,
            color: '#00B2EE',
            opacity: 0.7,
            // barGap:500
        },
        label: {
            normal: {
                position: 'right',
                show: true
            }
        },
// 									legend:{
// 										textStyle: {
// 											color: 'red'          // 图例文字颜色
// 										}
// 									},
        data: Object.keys(builderJson.charts).map(function (key) {
            return builderJson.charts[key];
        })
    }]
};
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}
// 企业生命周期结束
// 吸引投资能力开始
var myChartt = echarts.init(document.getElementById('main2'));

var builderJson = {
    // "all": 10887,
    "charts": {
        "杭州": 3237,
        "北京": 2164,
        "沈阳": 7561,
        "天津": 7778,
        "银川": 7355,

    }
};


var canvas = document.createElement('canvas');
var ctx = canvas.getContext('2d');
canvas.width = canvas.height = 100;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.globalAlpha = 0.08;
ctx.font = '20px Microsoft Yahei';
// ctx.translate(50, 50);
// ctx.rotate(-Math.PI / 4);


option = {
    backgroundColor: {
        type: 'pattern',
        image: canvas,
        repeat: 'repeat'
    },
    tooltip: {},
    title: [{
        text: '吸引投资能-TOP5',
        // subtext: '总计 ' + builderJson.all,
        x: '25%',
        top: '10',
        textAlign: 'left',
        textStyle: {
            color: 'white'
        }

    },],
    grid: {
        top: 50,
        width: '88%',
        bottom: '5%',
        left: 10,
        containLabel: true
    },
    xAxis: {
        show: false,
        type: 'value',
        max: builderJson.all,
        splitLine: {
            show: false
        }
    },
    yAxis: [{
        // show:false,
        type: 'category',
        data: Object.keys(builderJson.charts),
        axisLabel: {
            interval: 0,
            textStyle: {
                color: 'white',
                align: 'right'

            }

        },
        axisLine: {
            show: false
            //
        },
        axisTick: {
            show: false     //隐藏刻度

        }
    }],
    series: [{
        type: 'bar',
        stack: 'chart',
        barWidth: '16',
        z: 3,
        itemStyle: {
            barBorderRadius: 5,
            color: '#00B2EE',
            opacity: 0.7,
            // barGap:500
        },
        label: {
            normal: {
                position: 'right',
                show: true
            }
        },
        data: Object.keys(builderJson.charts).map(function (key) {
            return builderJson.charts[key];
        })
    }]
};
if (option && typeof option === "object") {
    myChartt.setOption(option, true);
}
// 吸引投资能力结束
// 城市高质量发展力开始
var myCharts = echarts.init(document.getElementById('main3'));

var builderJson = {
    // "all": 10887,
    "charts": {
        "杭州": 3237,
        "北京": 2164,
        "沈阳": 7561,
        "天津": 7778,
        "银川": 7355,

    }
};


var canvas = document.createElement('canvas');
var ctx = canvas.getContext('2d');
canvas.width = canvas.height = 100;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.globalAlpha = 0.08;
ctx.font = '20px Microsoft Yahei';
// ctx.translate(50, 50);
// ctx.rotate(-Math.PI / 4);


option = {
    backgroundColor: {
        type: 'pattern',
        image: canvas,
        repeat: 'repeat'
    },
    tooltip: {},
    title: [{
        text: '城市高质量发展-TOP5',
        // subtext: '总计 ' + builderJson.all,
        x: '25%',
        top: '10',
        textAlign: 'left',
        textStyle: {
            color: 'white'
        }

    }],
    grid: {
        top: 50,
        width: '88%',
        bottom: '5%',
        left: 10,
        containLabel: true
    },
    xAxis: {
        show: false,
        type: 'value',
        max: builderJson.all,
        splitLine: {
            show: false
        },

    },
    yAxis: [{
        // show:false,
        type: 'category',
        data: Object.keys(builderJson.charts),
        axisLabel: {
            interval: 0,
            textStyle: {
                color: 'white',
                align: 'right'

            }

        },
        axisLine: {
            show: false
            //
        },
        axisTick: {
            show: false     //隐藏刻度

        }
    }],
    series: [{
        type: 'bar',
        stack: 'chart',
        barWidth: '16',
        z: 3,
        itemStyle: {
            barBorderRadius: 5,
            color: '#00B2EE',
            opacity: 0.7,
            // barGap:500
        },
        label: {
            normal: {
                position: 'right',
                show: true
            }
        },
        data: Object.keys(builderJson.charts).map(function (key) {
            return builderJson.charts[key];
        })
    }]
};
if (option && typeof option === "object") {
    myCharts.setOption(option, true);
}
// 城市高质量发展结束
// 地图开始
// 基于准备好的dom，初始化echarts实例
//var myChart = echarts.init(document.getElementById('main'));

var chartrt = echarts.init(document.getElementById('main'));
var data = [

    {name: '唐山', value: 119},
    {name: '平顶山', value: 119},
    {name: '邢台', value: 119},
    {name: '德州', value: 120},
    {name: '济宁', value: 120},
    {name: '荆州', value: 127},
    {name: '宜昌', value: 130},
    {name: '义乌', value: 132},
    {name: '丽水', value: 133},
    {name: '洛阳', value: 134},
    {name: '秦皇岛', value: 136},
    {name: '株洲', value: 143},
    {name: '石家庄', value: 147},
    {name: '莱芜', value: 148},
    {name: '常德', value: 152},
    {name: '保定', value: 153},
    {name: '湘潭', value: 154},
    {name: '金华', value: 157},
    {name: '岳阳', value: 169},
    {name: '长沙', value: 175},
    {name: '衢州', value: 177},
    {name: '廊坊', value: 193},
    {name: '菏泽', value: 194},
    {name: '合肥', value: 229},
    {name: '武汉', value: 273},
    {name: '大庆', value: 279}
];
var geoCoordMap = {

    '唐山': [118.02, 39.63],
    '平顶山': [113.29, 33.75],
    '邢台': [114.48, 37.05],
    '德州': [116.29, 37.45],
    '济宁': [116.59, 35.38],
    '荆州': [112.239741, 30.335165],
    '宜昌': [111.3, 30.7],
    '义乌': [120.06, 29.32],
    '丽水': [119.92, 28.45],
    '洛阳': [112.44, 34.7],
    '秦皇岛': [119.57, 39.95],
    '株洲': [113.16, 27.83],
    '石家庄': [114.48, 38.03],
    '莱芜': [117.67, 36.19],
    '常德': [111.69, 29.05],
    '保定': [115.48, 38.85],
    '湘潭': [112.91, 27.87],
    '金华': [119.64, 29.12],
    '岳阳': [113.09, 29.37],
    '长沙': [113, 28.21],
    '衢州': [118.88, 28.97],
    '廊坊': [116.7, 39.53],
    '菏泽': [115.480656, 35.23375],
    '合肥': [117.27, 31.86],
    '武汉': [114.31, 30.52],
    '大庆': [125.03, 46.58]
};

var convertData = function (data) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = geoCoordMap[data[i].name];
        if (geoCoord) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].value)
            });
        }
    }
    return res;
};

option = {
    backgroundColor: '#151837',
    title: {
        text: '22参评城市中国营商环境总指数展示',
        //         subtext: 'data from PM25.in',
        //         sublink: 'http://www.pm25.in',
        left: 'center',
        top: '20',
        textStyle: {
            color: '#fff'
        }
    },
    tooltip: {
        trigger: 'item'
    },
    legend: {
        orient: 'vertical',
        y: 'bottom',
        x: 'left',
        bottom: 50,
        data: ['21-40', '61-80', '41-60'],
        textStyle: {
            color: 'white'
        }
    },
    // grid:{
    //      width :'60%'
    //  },
    geo: {
        map: 'china',
        zoom:1.2,
        label: {
            emphasis: {
                show: false
            }
        },
        roam: false,     //地图放大缩小
        itemStyle: {
            normal: {
                areaColor: '#44AED0',//021a67
                borderColor: '#111'
            },
            emphasis: {
                areaColor: '#2a333d'
            }
        }
    },
    series: [

        {
            name: '21-40',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: convertData(data),
            symbolSize: function (val) {
                return val[2] / 10;
            },

            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: false
                },
                emphasis: {
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: 'yellow'
                }
            }
        },
        {
            name: '61-80',
            type: 'effectScatter',
            coordinateSystem: 'geo',
            data: convertData(data.sort(function (a, b) {
                return b.value - a.value;
            }).slice(0, 6)),
            symbolSize: function (val) {
                return val[2] / 10;
            },
            showEffectOn: 'render',
            rippleEffect: {
                brushType: 'stroke'
            },
            hoverAnimation: true,
            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: 'blue',
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            zlevel: 1
        },
        {
            name: '41-60',
            type: 'effectScatter',
            coordinateSystem: 'geo',
            data: convertData(data.sort(function (a, b) {
                return b.value - a.value;
            }).slice(8, 14)),
            symbolSize: function (val) {
                return val[2] / 10;
            },
            showEffectOn: 'render',
            rippleEffect: {
                brushType: 'stroke'
            },
            hoverAnimation: true,
            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: 'red',
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            zlevel: 1
        }
    ]
};


chartrt.setOption(option);
// 地图结束

window.onresize = function(){
    myChart.resize();
    myChartt.resize();
    myCharts.resize();
    chartrt.resize()
};
