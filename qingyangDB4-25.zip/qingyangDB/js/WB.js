/*
* @Author : Dlxat
* @Title :  dlxat akang
* @project :qingyangDB
* @Date :   2019-04-24-17:51
*/

// 世行对标分析图开始
// 基于准备好的dom，初始化echarts实例
var myChart = echarts.init(document.getElementById("main"));
myChart.setOption({
    title: {

        text: '世行对标分析',
        top: '5%',
        textStyle: {
            color: '#144e87',

        }
    },
    tooltip: {
        trigger: 'axis'
    },
    color: ['#4aadc3', '#f3c525', '#FFFFFF'],
    legend: {
        right: '2%',
        top: '5%',
        data: ['世行最优指数', '世行中国指数', '庆阳营商环境指数'],
        textStyle: {
            fontSize: 15,
            color: '#144e87'
        }
    },
    grid: {
        show: false,
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true,
        width: '96%'     //表宽度
    },
    xAxis: {
        type: 'category',
        axisLine: {
            show: false
        },
        splitLine: {
            show: false
        },
        axisLabel: {
            interval: '0',

            textStyle: {
                color: '#144e87',
                align: 'center',
                fontSize: 10
                // padding: 2
            }
        },
        axisTick: {
            length: 2
        },

        splitArea: {show: false},//去除网格区域
        // length: 5,
        boundaryGap: ['2%', '2%'],   //表两边留白
        // data: ['开班企业','办理施工许可证','获得电力','获得用水','获得网络','不动产登记','缴纳税费','办理破产','注销企业',],
        data: []

    },
    yAxis: {
        show: true,
        type: 'value',
        boundaryGap: true,
        axisLine: {
            show: false
        },
        axisTick: {
            show: false  //刻度
        },
        axisLabel: {
            show: false  //数值
        },

        splitLine: {
            show: true,
            lineStyle: {
                color: '#1d2250'
            }
        }
    },
    series: [


        {
            name: '庆阳营商环境指数',
            type: 'line',
            // stack: '总量',
            // data:[50, 132, 101, 94, 90, 130, 110,100,46],
            data: [],
            label: {
                normal: {
                    formatter: '{c}',
                    position: 'top',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    lable: {
                        show: true,

                    },
                    lineStyle: {
                        color: '#4aadc3'
                    }
                }
            },

        },
        {
            name: '世行中国指数',
            type: 'line',
            data: [],
            label: {
                normal: {
                    formatter: '{c}',
                    position: 'top',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    lable: {
                        show: true
                    },
                    lineStyle: {
                        color: '#f3c525'
                    }
                }
            },
        },
        {
            name: '世行最优指数',
            type: 'line',
            data: [],
            label: {
                normal: {
                    formatter: '{c}\n北京',
                    position: 'top',
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    lable: {
                        show: true
                    },
                    lineStyle: {
                        color: '#FFFFFF'
                    }
                }
            },
        },

    ]
});
// 使用刚指定的配置项和数据显示图表。
// myChart.setOption(option);
$.get('data.json').done(function (data) {
    // 填入数据
    myChart.setOption({
        xAxis: {
            data: data.datat
        },

        series: [{
            // 根据名字对应到相应的系列
            name: '庆阳营商环境指数',
            data: data.datat1
        },
            {
                // 根据名字对应到相应的系列
                name: '世行中国指数',
                data: data.datat2
            },
            {
                // 根据名字对应到相应的系列
                name: '世行最优指数',
                data: data.datat3,
//
            },

        ]
    });
});
// 世行对标分析图结束

// 世行中国22城总指标开始
var myChartt = echarts.init(document.getElementById('main1'));
// 显示标题，图例和空的坐标轴
myChartt.setOption({
    title: {
        text: '世行中国22城总指标',
        top: '2%',
        textStyle: {
            color: '#144e87',
            align: 'center'
        }
    },
    grid: {
        show: false,
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true,
        width: '96%'     //表宽度
    },
    tooltip: {
        trigger: 'item',
        confine: true

    },
    xAxis: {
        data: [],
        // show:false,
        axisTick: {       //X轴刻度线
            show: false
        },
        axisLine: {
            show: false
        },
        splitLine: {
            show: false
        },
        axisLabel: {
            interval: '0',

            textStyle: {
                color: '#144e87',
                align: 'center',
                fontSize: 10
            }
        },

    },

    yAxis: {
        show: false,
    },
    series: [{
        name: '指标',
        type: 'bar',
        data: [],
        barWidth: 14,

        itemStyle: {

            normal: {
                color: 'red',
                label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    textStyle: { //数值样式
                        color: 'white',
                        fontSize: 12
                    }
                },

                barBorderRadius: [8, 8, 0, 0],
                color: new echarts.graphic.LinearGradient(
                    0, 0, 1, 0,
                    [
                        {offset: 0, color: '#181c41'},
                        {offset: 1, color: '#7fa6ce'}

                    ]
                )
            },

        }

    }]
});

// 异步加载数据
$.get('data.json').done(function (data) {
    // 填入数据
    myChartt.setOption({
        xAxis: {
            data: data.categories
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '指标',
            data: data.data
        }]
    });
});
// 世行中国22城总指标结束

// echarts自适应
window.onresize = function () {

    myChart.resize();

    myChartt.resize();


}
